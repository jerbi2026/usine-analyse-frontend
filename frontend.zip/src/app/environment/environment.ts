

export const environment = {
    production: false,
    firebase: {
        apiKey: "AIzaSyAsl0I_AaZZ5BjdFDEm6UGEp9d6Tld3YZ0",
        authDomain: "misfat-20a39.firebaseapp.com",
        projectId: "misfat-20a39",
        storageBucket: "misfat-20a39.firebasestorage.app",
        messagingSenderId: "859065564577",
        appId: "1:859065564577:web:2c00c2d6e6ee2656bddfe0",
        measurementId: "G-0NXHCGQRRW"
    }
  };  